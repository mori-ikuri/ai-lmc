import json,glob
seen={}
counts={}
for f in sorted(glob.glob('raw/Q*_p*.json')):
    q=f.split('/')[-1][:2]
    d=json.load(open(f))
    counts.setdefault(q,[d['total_count'],0]); counts[q][1]+=len(d['items'])
    for it in d['items']:
        fn=it['full_name']
        if fn not in seen:
            seen[fn]={'full_name':fn,'stars':it['stargazers_count'],'pushed_at':it['pushed_at'],
                      'default_branch':it['default_branch'],'language':it['language'],
                      'license':(it.get('license') or {}).get('spdx_id'),'archived':it['archived'],
                      'description':it['description'],'queries':[q]}
        elif q not in seen[fn]['queries']:
            seen[fn]['queries'].append(q)
lst=sorted(seen.values(), key=lambda r:(-r['stars'], r['full_name']))
for i,r in enumerate(lst,1): r['rank']=i
json.dump(lst,open('order.json','w'),ensure_ascii=False,indent=1)
print(counts, len(lst))
for r in lst[:30]: print(r['rank'],r['stars'],r['full_name'],r['language'],r['license'],r['queries'])
