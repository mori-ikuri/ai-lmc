import json,os,re,subprocess,sys,glob,shutil
from concurrent.futures import ThreadPoolExecutor
C='2023-10-06'
ORDER=json.load(open('order.json'))
RES='results.jsonl'
done={json.loads(l)['rank'] for l in open(RES)} if os.path.exists(RES) else set()
EXCL=re.compile(r'(^|/)(bin|obj|packages|\.git)(/|$)',re.I)
def rd(p):
    try: return open(p,encoding='utf-8',errors='replace').read()
    except Exception: return ''
def proj_files(projpath):
    d=os.path.dirname(projpath); t=rd(projpath)
    sdk='<Project Sdk=' in t or re.search(r'<Project\s[^>]*Sdk=',t)
    exts=('.vb','.cs')
    files=[]
    if not sdk:
        for inc in re.findall(r'<Compile\s+Include="([^"]+)"',t):
            inc=inc.replace('\\','/')
            p=os.path.normpath(os.path.join(d,inc))
            if '*' in inc: files+= [x for x in glob.glob(p,recursive=True)]
            elif os.path.isfile(p): files.append(p)
    else:
        for root,ds,fs in os.walk(d):
            if EXCL.search(os.path.relpath(root,d).replace('\\','/')): continue
            files+= [os.path.join(root,f) for f in fs]
    return [f for f in set(files) if f.lower().endswith(exts) and not EXCL.search(f.replace('\\','/'))]
def proj_refs(projpath):
    d=os.path.dirname(projpath); out=[]
    for inc in re.findall(r'<ProjectReference\s+Include="([^"]+)"',rd(projpath)):
        p=os.path.normpath(os.path.join(d,inc.replace('\\','/')))
        if os.path.isfile(p): out.append(p)
    return out
CLS_VB=re.compile(r'^\s*(?:(?:Public|Friend|Private|Partial|MustInherit|NotInheritable|Protected)\s+)*Class\s+(\w+)[^\n]*\n(?:\s*(?:\'[^\n]*)?\n)*\s*Inherits\s+([\w\.]+)',re.M|re.I)
CLS_CS=re.compile(r'\bclass\s+(\w+)(?:\s*<[^>]*>)?\s*:\s*([\w\.]+)')
def bases(files):
    m={}
    for f in files:
        t=rd(f)
        pat=CLS_VB if f.lower().endswith('.vb') else CLS_CS
        for c,b in pat.findall(t):
            m.setdefault(c,set()).add(b.split('.')[-1] if b.lower().startswith('system.windows.forms.') else b.split('.')[-1])
    return m
def forms(files):
    m=bases(files); fs=set()
    changed=True
    for c,bs in m.items():
        if any(b=='Form' for b in bs): fs.add(c)
    while changed:
        changed=False
        for c,bs in m.items():
            if c not in fs and any(b in fs for b in bs): fs.add(c); changed=True
    return fs
def lines(files): 
    n=0
    for f in files:
        try: n+=open(f,'rb').read().count(b'\n')
        except Exception: pass
    return n
DB=re.compile(r'\b(SqlConnection|SqlCeConnection|MySqlConnection|SQLiteConnection|SqliteConnection|NpgsqlConnection|OracleConnection|FbConnection|DbContext|DataContext|NHibernate|ISessionFactory|OleDbConnection|OdbcConnection|SqlClient|MySql\.Data|System\.Data\.SQLite)\b')
STRONG={'SqlConnection','SqlCeConnection','MySqlConnection','SQLiteConnection','SqliteConnection','NpgsqlConnection','OracleConnection','FbConnection','DbContext','DataContext','NHibernate','ISessionFactory','SqlClient','MySql.Data','System.Data.SQLite'}
LIC_OK={'MIT':'MIT','APACHE':'Apache-2.0','BSD':'BSD'}
def license_of(root):
    cands=[f for f in os.listdir(root) if re.match(r'(license|licence|copying)',f,re.I)]
    t=' '.join(rd(os.path.join(root,f)) for f in cands if os.path.isfile(os.path.join(root,f)))
    src='file:'+','.join(cands) if cands else None
    if not t:
        rm=[f for f in os.listdir(root) if f.lower().startswith('readme')]
        t=' '.join(rd(os.path.join(root,f)) for f in rm if os.path.isfile(os.path.join(root,f)))
        src='readme' if t else None
    T=t.upper()
    if 'PERMISSION IS HEREBY GRANTED, FREE OF CHARGE' in T or re.search(r'\bMIT LICEN[SC]E\b',T): return 'MIT',src
    if 'APACHE LICENSE' in T and ('VERSION 2.0' in T or '2.0' in T): return 'Apache-2.0',src
    if 'REDISTRIBUTION AND USE IN SOURCE AND BINARY FORMS' in T: return 'BSD',src
    if 'GNU GENERAL PUBLIC' in T or 'GNU LESSER' in T or 'GNU AFFERO' in T: return 'GPL-family',src
    if 'MICROSOFT PUBLIC LICENSE' in T: return 'MS-PL',src
    if not T.strip(): return None,src
    return 'other',src
def check(r):
    name=r['full_name']; d='work/'+name.replace('/','__')
    res={'rank':r['rank'],'full_name':name,'stars':r['stars']}
    try:
        p=subprocess.run(['git','clone','-q','--depth','1','--no-tags','--single-branch',f'https://github.com/{name}.git',d],capture_output=True,timeout=240,env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GIT_LFS_SKIP_SMUDGE':'1'})
        if p.returncode!=0 or not os.path.isdir(d):
            res.update(result='unavailable',basis=p.stderr.decode(errors='replace')[-200:]); return res
        commit=subprocess.run(['git','-C',d,'log','-1','--format=%H %cI'],capture_output=True,text=True).stdout.strip()
        res['head']=commit
        projs=[]
        for root,ds,fs in os.walk(d):
            if '.git' in root.split(os.sep): continue
            for f in fs:
                if f.lower().endswith(('.vbproj','.csproj')): projs.append(os.path.join(root,f))
        cand=[]
        for pj in projs:
            t=rd(pj)
            if re.search(r'<OutputType>\s*WinExe\s*</OutputType>',t,re.I):
                fl=proj_files(pj); fm=forms(fl)
                if fm: cand.append((len(fm),pj,fl,fm))
        if not cand:
            res.update(result='fail',criterion=1,basis=f'no WinExe project with a Form class ({len(projs)} project files)'); return res
        cand.sort(key=lambda x:(-x[0],x[1]))
        n,pj,fl,fm=cand[0]
        rel=os.path.relpath(pj,d); res['app']=rel
        t=rd(pj)
        tfv=re.search(r'<TargetFrameworkVersion>\s*v?([\d\.]+)',t)
        tfs=re.search(r'<TargetFrameworks?>([^<]+)<',t)
        fw=tfv.group(1) if tfv else (tfs.group(1) if tfs else None)
        ok2=False
        if tfv: ok2=tfv.group(1).startswith('4')
        elif tfs: ok2=any(re.fullmatch(r'net4\d+',x.strip()) for x in tfs.group(1).split(';'))
        res['framework']=fw
        if not ok2:
            res.update(result='fail',criterion=2,basis=f'{rel}: framework {fw}'); return res
        allf=set(fl); seen={pj}; stack=proj_refs(pj)
        while stack:
            q=stack.pop()
            if q in seen: continue
            seen.add(q)
            if re.search(r'test',os.path.basename(q),re.I): continue
            allf|=set(proj_files(q)); stack+=proj_refs(q)
        hits=set()
        for f in allf: hits|=set(DB.findall(rd(f)))
        res['db_hits']=sorted(hits)
        if not hits:
            res.update(result='fail',criterion=3,basis='no relational-database access found in application source'); return res
        if not (hits & STRONG): res['c3_manual']=True
        allfm=forms(list(allf)); ln=lines(allf)
        res['lines']=ln; res['forms']=len(allfm); res['files']=len(allf)
        if ln<5000 or len(allfm)<8:
            res.update(result='fail',criterion=4,basis=f'{ln} lines, {len(allfm)} forms'); return res
        lic,src=license_of(d); res['license']=lic; res['license_src']=src
        if lic not in ('MIT','Apache-2.0','BSD'):
            res.update(result='fail',criterion=5,basis=f'licence {lic} ({src})'); return res
        date=commit.split(' ')[1][:10] if ' ' in commit else ''
        if not date or date>=C:
            res.update(result='fail',criterion=6,basis=f'last default-branch commit {commit}'); return res
        res.update(result='pending-c7',basis='criteria 1-6 passed by script; criterion 7 and manual checks pending')
        return res
    except Exception as e:
        res.update(result='error',basis=repr(e)[:200]); return res
    finally:
        shutil.rmtree(d,ignore_errors=True)
if __name__=='__main__':
    lo,hi,W=int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3])
    todo=[r for r in ORDER if lo<=r['rank']<=hi and r['rank'] not in done]
    os.makedirs('work',exist_ok=True)
    with ThreadPoolExecutor(W) as ex, open(RES,'a') as out:
        for res in ex.map(check,todo):
            out.write(json.dumps(res,ensure_ascii=False)+'\n'); out.flush()
